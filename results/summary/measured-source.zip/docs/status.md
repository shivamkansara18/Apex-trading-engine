# Project status

## Current milestone

Phase 7: repeated throughput/latency baseline harness implemented and measured.
Phases 0-7 local deliverables are ready; hosted CI remains unverified.

## Environment inspected

- Local host: macOS / Darwin, arm64.
- Compiler: Apple Clang 21.0.0, C++20 available.
- Git: 2.55.0.
- Native Homebrew CMake 4.5.0 and Ninja 1.13.2; no venv activation needed.
- Python 3.14; pypdf installed locally to read the supplied 17-page guide.
- Primary development, test and local benchmark target: macOS arm64, per user
  direction. Linux performance evaluation is optional later.

## Verification

- Phase 7 native macOS Debug: 90/90 CTest tests passed.
- Phase 7 native AddressSanitizer + UndefinedBehaviorSanitizer: 90/90 tests passed.
- Phase 7 native unsanitized Release benchmark build: 90/90 tests passed.
- One-command baseline script completed: 100,000 commands, five repetitions,
  one warm-up pass and 500,000 raw latency samples. CSV/JSON arithmetic and
  percentiles independently verified with the standard-library analysis tool.
- Local artifact bundle: `results/raw/phase7-macos-baseline`; interpretation
  and exact measurements are in `performance-report.md`.
- Fresh source copy under `tmp/phase0-clean`: Release configure/build/run passed,
  2/2 tests passed. Reused the downloaded GoogleTest source explicitly via
  `FETCHCONTENT_SOURCE_DIR_GOOGLETEST`; this was not a remote clone test.
- CLI generation, repeat multi-symbol runs, optional journal/replay and invalid
  options verified separately. No compiler warnings observed in these builds.
- Local Git repository initialized. No commit or remote created.
- Linux CI workflow written, but not executed remotely. Hosted CI and clean-clone
  verification remain release tasks; local development proceeds on macOS.

Checks cover foundation, domain, storage and matching scenarios. A seeded
1,500-command stream reproduces identical events and snapshots between two engines.
A separate seeded 1,200-command risk stream verifies rejection immutability and
independent participant usage totals. Phase 5 adds file-backed exact output replay,
byte-identical seeded runs, corruption/truncation checks, and actual write-failure
injection. Phase 6 adds deterministic role-based generation, all six workload
profiles, multi-symbol isolation, lossless saved inputs and journal integration.
Phase 7 adds a separate measured baseline; prior checks remain correctness evidence.

## Phase 1 decisions

- Fixed-width integer units; tagged command/event payloads; owning snapshots.
- Separate command, event and trade counters, starting at one without wrap.
- Accepted state distinguishes validated incoming orders from resting book orders.
- Cancellation retains the unexecuted quantity for audit; replace quantity is
  desired remaining quantity. Rejected replace retains both requested IDs.
- Detailed contracts are in `domain-model.md` and `matching-rules.md`.

## Phase 3 decisions

- Resting-price executions, FIFO by command sequence, and cancellation of incoming
  remainder on self-trade (earlier fills stand).
- Replace validates first, always resets priority, and treats new quantity as
  desired remaining quantity.
- Basic command validation is in place; Phase 4 now adds mandatory participant
  registration and configurable risk policies before matching.
- Side-total capacity uses conservative full-size admission, credited for the
  old remaining quantity on replace. Event capacity is reserved before processing.
- Exact event ordering and fatal exception policy are in `matching-engine.md`.

## Phase 4 decisions

- Explicit registration; per-order notional in tick-units, not aggregate exposure.
- Market notional/bands use executable liquidity up to self-trade prevention;
  failures reject the whole command before any fills.
- Open-order slots are conservative for limits; replace credits one slot and
  old remaining quantity. Market orders do not need a resting slot.
- Usage derives from the authoritative book; no separate cached risk ledger yet.
- Kill switches block new/replace, preserve resting orders and allow cancels.
- Admin configuration is single-writer; the Phase 5 facade now records it for replay.
- Full policies and API examples are in `risk-controls.md`.

## Phase 5 decisions

- Exclusive new-file creation, explicit big-endian versioned format, fixed-width
  fields and bounded record lengths. No raw-struct serialization.
- One input/output record per admin action or command, including rejections;
  consecutive journal record IDs and CRC-32 detect accidental damage.
- Synchronous complete writes plus fsync before returning results; journal I/O
  stays outside matching. Any processing/write/sync error stops the session.
- Explicit terminal seal detects incomplete logs even at record boundaries.
  Strict replay requires a complete sealed session; no partial-tail repair or
  resumable live-engine recovery is implemented.
- Replay compares canonical output bytes and book hashes per record. FNV-1a
  reports cover book/event state; hashes/checksums are not cryptographic.
- Format, guarantees and limitations are in `journal-and-replay.md`.

## Phase 6 decisions

- Native C++20 simulation, mt19937_64 plus explicit integer sampling, ordered live
  target selection and shadow engines. Same seed/config/version gives same input.
- Providers quote passively, takers use markets, random flow mixes types; a
  scripted profile exercises large partial fills. Six presets are available.
- Versioned text workloads include full generator config and ordered scheduled
  commands. Limits, entry count, terminal marker and ranges are checked on load.
- Multiple symbols route to isolated engines with local sequence numbers and
  registries. Journal recording currently supports one symbol only.
- Scheduling is logical metadata; the correctness runner does not sleep or
  measure latency/throughput. Generator/loader are outside future timed regions.
- Details, caveats and commands are in `workloads.md`.

## Phase 7 decisions

- Separate throughput and latency passes using the same saved workload; no
  generation, file output or final verification in the timed matching interval.
- Untimed full warm-up runs and fresh registered engines for every measured pass.
- Closed-loop synchronous engine scope; no queue, network or journal timing.
- Nearest-rank percentiles; p99.9 omitted below 100,000 samples per run. Report
  all repetitions, medians and variability, preserving raw samples.
- Release-only benchmark executable; tests cover metrics in Debug/ASan too.
- Machine/compiler/flags, source SHA-256, workload identity, clock diagnostics
  and process peak RSS are recorded. No optimization/speedup claim yet.
- See `benchmark-methodology.md` and `performance-report.md`.

## Next step

Phase 8: profile the baseline on this Mac, then compare at least three measured
experiments against the same saved inputs, preserving correctness and replay.
Linux perf remains optional on a Linux host. Later phases add networking,
backpressure and a graphical interface.

Run `bash scripts/run_baseline.sh` for a fresh benchmark bundle, or
`python3 tools/analyze_results.py results/raw/phase7-macos-baseline` to verify
the captured local result. Existing core demos remain available. No venv is required.
