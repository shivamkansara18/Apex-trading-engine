# Architecture

## Implemented foundation

`apex_core` is a C++20 library with a version API. `apex` is the terminal entry
point. `apex_tests` links the same library through GoogleTest. `apex_options`
provides warnings and optional sanitizer instrumentation for project targets.
Domain headers define commands, orders, trades, events and owning snapshots;
see [domain model](domain-model.md). They have no platform-specific dependencies.
`OrderBook` owns map/list storage, an ID index and cached side quantities.
See [order-book storage](order-book.md). `MatchingEngine` owns the book and
sequence counters, processes variant commands synchronously, and returns ordered
events. See [matching engine](matching-engine.md). The terminal `--trading-demo`
shows actual executions; `--book-demo` shows storage. No worker threads or sockets
exist yet.

Phase 4 adds `RiskManager`, owned by the engine. It keeps participant limits and
global admission state, derives usage from the authoritative book, and preflights
market risk before mutation. See [risk controls](risk-controls.md). Configuration
is single-writer; no concurrent admin changes are supported.

Phase 5 adds a `JournaledEngine` facade. It records every admin/command input and
the canonical result outside matching, syncs before returning, and seals sessions
explicitly. Strict replay rebuilds a fresh engine and verifies events and book
hashes at each record. See [journal and replay](journal-and-replay.md).

Phase 6 adds a simulator with seeded provider/taker/random agents and a scripted
large-fill profile. It saves versioned scheduled commands outside matching. A
correctness runner dispatches each symbol to its own engine and checks invariants;
optional single-symbol runs use the journal facade. Neither scheduling nor
generation adds clocks/I/O to the core. See [workloads](workloads.md).

Phase 7 adds a separate `apex_metrics` library and Release-only `apex_benchmark`
executable. It prepares engines outside timing, runs independent bulk/latency
passes, verifies outputs against the correctness runner, then exports metadata
and raw samples. Core matching remains free of benchmark clocks and file I/O.
See [benchmark methodology](benchmark-methodology.md).

## Planned ownership and flow

The gateway parses framed input and verifies session identity, then transfers
commands into a bounded ingress queue. One engine thread validates commands and
owns all mutable order-book state. The book uses price maps, FIFO order lists,
and an order index. Queries expose snapshots rather than mutable containers.

The engine produces ordered events for execution reports, journaling, and market
data. Consumers must not mutate engine state. Blocking network/disk operations
belong outside matching. Durable acknowledgement policy and journal failure
behavior is defined for the Phase 5 synchronous wrapper in the journal document.

Replay starts from an empty book using recorded configuration and command order.
Wall-clock time and client timestamps cannot influence matching decisions.
Networking adds concurrency around this core without changing single-writer
ownership. No lock-free structure is planned until a measured bottleneck exists.
